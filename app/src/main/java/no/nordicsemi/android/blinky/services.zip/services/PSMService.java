package no.nordicsemi.android.blinky.services;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import no.nordicsemi.android.ble.livedata.state.ConnectionState;

public class PSMService extends Service {
    private final static String TAG = BLEPSMManager.class.getSimpleName();
    public String deviceAdress;
    private ExecutorService thread;
    private PSMServiceBinder serviceBinder;
    BluetoothDevice device;


    public enum State {
    CONNECTING,
    INITIALIZING,
    READY,
    DISCONNECTING,
    DISCONNECTED
}
    private MutableLiveData<State> connectionState ;
    private MutableLiveData<String> tempereture;

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothGatt mBluetoothGatt;

    public boolean initialize() {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }
       if(!connect()){
           return false;
       }


        return true;
    }

    private boolean connect() {
        if (mBluetoothAdapter == null || deviceAdress == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        // Previously connected device.  Try to reconnect.
        if(device != null) {
            if (deviceAdress != null && device.getAddress().equals(deviceAdress)
                    && mBluetoothGatt != null) {
                Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
                Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
                if (mBluetoothGatt.connect()) {
                    connectionState.postValue(State.CONNECTING);
                    return true;
                } else {
                    return false;
                }
            }
        }

        device = mBluetoothAdapter.getRemoteDevice(deviceAdress);
        if (device == null) {
            Log.w(TAG, "Device not found.  Unable to connect.");
            return false;
        }
        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        mBluetoothGatt = device.connectGatt(this, false, mGattCallback);
        Log.d(TAG, "Trying to create a new connection.");
        connectionState.postValue(State.CONNECTING);
        return true;
    }

    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        connectionState.postValue(State.DISCONNECTING);
        mBluetoothGatt.disconnect();
        connectionState.postValue(State.DISCONNECTED);

    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.readCharacteristic(characteristic);
    }


    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);

        // This is specific to Heart Rate Measurement.
        if (UUID_HEART_RATE_MEASUREMENT.equals(characteristic.getUuid())) {
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(
                    UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            mBluetoothGatt.writeDescriptor(descriptor);
        }
    }


    
    @Override
    public void onCreate() {
        super.onCreate();
        this.thread = Executors.newFixedThreadPool(1);
        this.serviceBinder = new PSMServiceBinder();
        boolean initState = this.initialize();

        this.tempereture = new MutableLiveData<>();

    }

    @Override
    public IBinder onBind(Intent intent) {
        return serviceBinder;
    }

    private void updateTemperature(final BluetoothGattCharacteristic characteristic) {


        // This is special handling for the Heart Rate Measurement profile.  Data parsing is
        // carried out as per profile specifications:
        // http://developer.bluetooth.org/gatt/characteristics/Pages/CharacteristicViewer.aspx?u=org.bluetooth.characteristic.heart_rate_measurement.xml

            // For all other profiles, writes the data formatted in HEX.
            final byte[] data = characteristic.getValue();
            if (data != null && data.length > 0) {
                final StringBuilder stringBuilder = new StringBuilder(data.length);
                for(byte byteChar : data)
                    stringBuilder.append(String.format("%02X ", byteChar));
                tempereture.postValue(new String(data) + "\n" + stringBuilder.toString());

            }


    }


    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change and services discovered.
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectionState.postValue(State.INITIALIZING);
                Log.i(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Log.i(TAG, "Attempting to start service discovery:" +
                        mBluetoothGatt.discoverServices());

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectionState.postValue(State.DISCONNECTED);
                Log.i(TAG, "Disconnected from GATT server.");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.w(TAG, "GATT SERVICE SUCCEEDED: " + status);
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                updateTemperature(characteristic);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
//            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
              if (characteristic != null) {
                  updateTemperature(characteristic);
              }
              else{
                  Log.w(TAG, "characteristic is null!");
              }
        }

    };



    public class PSMServiceBinder extends Binder {
        public String deviceAdress;


        public PSMService getService(){
            return PSMService.this;
        }
    }

    public static class PSMServiceConnection implements ServiceConnection {

        private PSMServiceBinder binder;
        private boolean isConnected;
        public  String deviceAdress;

        PSMServiceConnection(String deviceAddress){
            super();
            this.deviceAdress = deviceAddress;
        }
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            this.binder = (PSMServiceBinder)service;
            this.binder.getService();
            try{
                this.binder.deviceAdress= deviceAdress;
            }
            catch (Exception e){
                e.printStackTrace();
            }
            this.isConnected = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            this.isConnected = false;
        }

        public PSMService getService(){
            return binder.getService();
        }
    }
}